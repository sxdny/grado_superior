//public class TablaEnteroMain {
//
//	public static void main(String[] args) {
//		
//		Integer[] enteros = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
//		Integer[] enterosVacio = new Integer[0];
//		Integer[] enterosNegativos = { 1, -5, -45, -2002003, -200000 };
//		
//		TablaEntero tE1 = new TablaEntero(enteros);
//		TablaEntero tE2 = new TablaEntero(enteros);
//		TablaEntero tE3 = new TablaEntero(enterosNegativos);
//		
//		System.out.println(tE3.sumaTabla());
//
//	}
//
//}
